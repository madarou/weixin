package org.sword.wechat4j;

import static org.junit.Assert.*;

import org.junit.Test;
import org.sword.wechat4j.message.CustomerMsg;

import com.alibaba.fastjson.JSONObject;



public class SendMsgTest {
	CustomerMsg senMsg = new CustomerMsg("");
	
	@Test
	public void testSendText() {
//		String expected = "Hello World";
//		senMsg.sendText(expected);
////		String actual = senMsg.getMsgBody();
//		JSONObject json = JSONObject.parseObject(actual);
//		actual = json.getJSONObject("text").getString("content");
//		
//		assertEquals(expected, actual);
	}

//	@Test
//	public void testSendImage() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testSendVoice() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testSendVideoStringStringStringString() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testSendVideoVideoResponse() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testSendMusicStringStringStringStringString() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testSendMusicMusicResponse() {
//		fail("Not yet implemented");
//	}

	@Test
	public void testsendNew() {
//		String expected = "Hello World";
//		senMsg.sendNew("title", expected, "picUrl", "picUrl");
//		String actual = senMsg.getMsgBody();
//		JSONObject json = JSONObject.parseObject(actual);
//		actual = json.getJSONObject("news").getJSONArray("articles").getJSONObject(0).getString("description");
//		
//		assertEquals(expected, actual);
	}
}
