package org.sword.wechat4j;

import static org.junit.Assert.*;

import org.junit.Test;

public class WechatSupportTest {

	@Test
	public void test() {
		
	}

}
