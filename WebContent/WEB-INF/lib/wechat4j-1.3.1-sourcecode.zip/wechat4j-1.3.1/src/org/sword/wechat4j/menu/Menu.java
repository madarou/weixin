package org.sword.wechat4j.menu;

import java.util.List;


/**
 * 微信菜单
 * @author Zhangxs
 * @version 2015-7-4
 */
public class Menu {
	private List<MenuButton> button;

	public List<MenuButton> getButton() {
		return button;
	}

	public void setButton(List<MenuButton> button) {
		this.button = button;
	}
	
}
