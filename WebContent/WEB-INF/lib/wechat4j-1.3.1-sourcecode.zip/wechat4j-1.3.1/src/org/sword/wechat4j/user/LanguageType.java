package org.sword.wechat4j.user;
/**
 * 语言种类
 * @author Zhangxs
 * @version 2015-7-5
 */
public enum LanguageType {
	/** 简体 */
	zh_CN,
	/** 繁体 */
	zh_TW,
	/** 英语 */
	en;

}
