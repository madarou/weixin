/**
 * 
 */
package org.sword.wechat4j.token.server;



/**
 * accessToken中控服务器
 * @author ChengNing
 * @date   2015年1月9日
 */
public interface TokenServer {
	
	public String token();
}
