/**
 * 
 */
package org.sword.wechat4j.common;

/**
 * 微信菜单操作
 * @author chengn
 * @date   2015年5月11日
 */
public class Menu {
	
	/**
	 * 创建
	 */
	public void create(){
		
	}
	
	/**
	 * 更新
	 */
	public void update(){
		
	}
	
	/**
	 * 删除
	 */
	public void delete(){
		
	}
}
