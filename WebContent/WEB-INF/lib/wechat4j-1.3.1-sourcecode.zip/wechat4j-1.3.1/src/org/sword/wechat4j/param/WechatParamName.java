/**
 * 
 */
package org.sword.wechat4j.param;

/**
 * 微信接口中get请求方式中的参数名称
 * @author ChengNing
 * @date   2014-12-4
 */
public class WechatParamName {
	
	public static final String ECHOSTR = "echostr";
	public static final String SIGNATURE = "signature";
	public static final String TIMESTAMP = "timestamp";
	public static final String NONCE = "nonce";
	
	
}
