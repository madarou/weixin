/**
 * 
 */
package org.sword.wechat4j.token.server;

/**
 * @author ChengNing
 * @date   2015年1月29日
 */
public interface TicketServer {
	
	public String ticket();
}
