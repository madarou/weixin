/**
 * 
 */
package org.sword.wechat4j.token;

/**
 * @author ChengNing
 * @date   2015年1月29日
 */
public enum TicketType {
	/**
	 * jsapi_ticket
	 */
	jsapi
}
