/**
 * 
 */
package org.sword.wechat4j.common;

/**
 * @author ChengNing
 * @date   2015年1月26日
 */
public enum MediaType {
	image,
	voice,
	video,
	thumb
}
