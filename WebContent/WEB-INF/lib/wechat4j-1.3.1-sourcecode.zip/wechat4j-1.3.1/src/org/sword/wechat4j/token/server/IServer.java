/**
 * 
 */
package org.sword.wechat4j.token.server;


/**
 * 
 * @author ChengNing
 * @date   2015年1月7日
 */
public interface IServer {
	
	public String token();
//	
//	public IServer server();
//	
//	public IServer customerServer();
//	
}
